package com.example;

import java.io.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Hotel {
    private List<Customer> customers;
    private List<Room> rooms;
    private static final String FILE_NAME = "customers.txt";

    public Hotel() {
        this.customers = new ArrayList<>();
        this.rooms = new ArrayList<>();
        for (int i = 1; i <= 100; i++) {
            rooms.add(new Room(i));
        }
        loadCustomersFromFile();
    }

    public void checkIn(String name, int roomNumber, LocalDate checkInDate, LocalDate checkOutDate) {
        if (checkInDate.isBefore(LocalDate.now())) {
            System.out.println("Cannot check-in with a past date.");
            return;
        }

        Room room = findRoom(roomNumber);
        if (room != null) {
            if (room.isOccupied()) {
                System.out.println("Room " + roomNumber + " is already occupied.");
            } else {
                room.setOccupied(true);
                customers.add(new Customer(name, roomNumber, checkInDate, checkOutDate));
                saveCustomersToFile();
                System.out.println("Check-in successful: " + name);
            }
        } else {
            System.out.println("Room " + roomNumber + " does not exist.");
        }
    }

    public void checkOut(int roomNumber) {
        Room room = findRoom(roomNumber);
        if (room != null && room.isOccupied()) {
            Customer customer = findCustomerByRoomNumber(roomNumber);
            if (customer != null) {
                customers.remove(customer);
                room.setOccupied(false);
                saveCustomersToFile();
                System.out.println("Check-out successful: " + customer.getName());
            }
        } else {
            System.out.println("No customer found in room number " + roomNumber);
        }
    }

    public List<Customer> getCustomers() {
        return customers;
    }

    public Room findRoom(int roomNumber) {
        for (Room room : rooms) {
            if (room.getRoomNumber() == roomNumber) {
                return room;
            }
        }
        return null;
    }

    public void displayCustomers() {
        if (customers.isEmpty()) {
            System.out.println("No customers checked in.");
        } else {
            System.out.println("Customers checked in:");
            for (Customer customer : customers) {
                System.out.println(customer);
            }
        }
    }

    public void displayRooms() {
        System.out.println("Room occupancy status:");
        for (Room room : rooms) {
            System.out.println(room);
        }
    }

    public void loadCustomersFromFile() {
        try (BufferedReader br = new BufferedReader(new FileReader(FILE_NAME))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] data = line.split(",");
                if (data.length == 4) {
                    try {
                        String name = data[0];
                        int roomNumber = Integer.parseInt(data[1]);
                        LocalDate checkInDate = LocalDate.parse(data[2]);
                        LocalDate checkOutDate = LocalDate.parse(data[3]);
                        customers.add(new Customer(name, roomNumber, checkInDate, checkOutDate));
                        findRoom(roomNumber).setOccupied(true);
                    } catch (NumberFormatException | ArrayIndexOutOfBoundsException e) {
                        System.out.println("Malformed line in data file: " + line);
                    }
                } else {
                    System.out.println("Malformed line in data file: " + line);
                }
            }
        } catch (FileNotFoundException e) {
            System.out.println("No previous data found, starting fresh.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void saveCustomersToFile() {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(FILE_NAME))) {
            for (Customer customer : customers) {
                bw.write(customer.getName() + "," + customer.getRoomNumber() + "," + customer.getCheckInDate() + "," + customer.getCheckOutDate());
                bw.newLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private Customer findCustomerByRoomNumber(int roomNumber) {
        for (Customer customer : customers) {
            if (customer.getRoomNumber() == roomNumber) {
                return customer;
            }
        }
        return null;
    }
}
