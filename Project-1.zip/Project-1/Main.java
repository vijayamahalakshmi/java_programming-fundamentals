package com.example;


import java.time.LocalDate;


import java.util.Scanner;


public class Main {
    public static void main(String[] args) {
        Hotel hotel = new Hotel();
        Scanner scanner = new Scanner(System.in);
        boolean running = true;

        while (running) {
            System.out.println("\nHotel Management System");
            System.out.println("1. Check-in");
            System.out.println("2. Check-out");
            System.out.println("3. Display Customers");
            System.out.println("4. Display Rooms");
            System.out.println("5. Exit");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            switch (choice) {
                case 1:
                    System.out.print("Enter name: ");
                    String name = scanner.nextLine();
                    System.out.print("Enter room number: ");
                    int roomNumber = scanner.nextInt();
                    scanner.nextLine();  // Consume newline
                    System.out.print("Enter check-in date (YYYY-MM-DD): ");
                    LocalDate checkInDate = LocalDate.parse(scanner.nextLine());
                    System.out.print("Enter check-out date (YYYY-MM-DD): ");
                    LocalDate checkOutDate = LocalDate.parse(scanner.nextLine());
                    hotel.checkIn(name, roomNumber, checkInDate, checkOutDate);
                    break;

                case 2:
                    System.out.print("Enter room number: ");
                    int roomNum = scanner.nextInt();
                    hotel.checkOut(roomNum);
                    break;

                case 3:
                    hotel.displayCustomers();
                    break;

                case 4:
                    hotel.displayRooms();
                    break;

                case 5:
                    running = false;
                    break;

                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }

        scanner.close();
    }
}
