package com.example;

import static org.junit.Assert.*;
import java.time.LocalDate;
import org.junit.Before;
import org.junit.Test;

public class TestCases {

    private Hotel hotel;

    @Before
    public void setUp() {
        hotel = new Hotel();
    }

    @Test
    public void testCheckInMultipleRooms() {
        LocalDate checkInDate1 = LocalDate.now();
        LocalDate checkOutDate1 = LocalDate.now().plusDays(1);
        LocalDate checkInDate2 = LocalDate.now().plusDays(2);
        LocalDate checkOutDate2 = LocalDate.now().plusDays(3);

        hotel.checkIn("John Doe", 1, checkInDate1, checkOutDate1);
        hotel.checkIn("Jane Smith", 2, checkInDate2, checkOutDate2);

        assertEquals("Expected 2 customers after checking in 2 rooms", 2, hotel.getCustomers().size());
        assertTrue("Room 1 should be occupied", hotel.findRoom(1).isOccupied());
        assertTrue("Room 2 should be occupied", hotel.findRoom(2).isOccupied());
    }

    @Test
    public void testCheckOutMultipleRooms() {
        LocalDate checkInDate1 = LocalDate.now();
        LocalDate checkOutDate1 = LocalDate.now().plusDays(1);
        LocalDate checkInDate2 = LocalDate.now().plusDays(2);
        LocalDate checkOutDate2 = LocalDate.now().plusDays(3);

        hotel.checkIn("John Doe", 1, checkInDate1, checkOutDate1);
        hotel.checkIn("Jane Smith", 2, checkInDate2, checkOutDate2);
        hotel.checkOut(1);
        hotel.checkOut(2);

        assertTrue("Customer list should be empty after checking out both rooms", hotel.getCustomers().isEmpty());
        assertFalse("Room 1 should be unoccupied", hotel.findRoom(1).isOccupied());
        assertFalse("Room 2 should be unoccupied", hotel.findRoom(2).isOccupied());
    }

    @Test
    public void testCheckInAndCheckOutSameRoom() {
        LocalDate checkInDate1 = LocalDate.now();
        LocalDate checkOutDate1 = LocalDate.now().plusDays(1);
        LocalDate checkInDate2 = LocalDate.now().plusDays(2);
        LocalDate checkOutDate2 = LocalDate.now().plusDays(3);

        hotel.checkIn("John Doe", 1, checkInDate1, checkOutDate1);
        assertEquals("Expected 1 customer after first check-in", 1, hotel.getCustomers().size());
        assertTrue("Room 1 should be occupied after first check-in", hotel.findRoom(1).isOccupied());

        hotel.checkOut(1);
        assertFalse("Room 1 should be unoccupied after check-out", hotel.findRoom(1).isOccupied());
        assertTrue("Customer list should be empty after check-out", hotel.getCustomers().isEmpty());

        hotel.checkIn("Jane Smith", 1, checkInDate2, checkOutDate2);
        assertEquals("Expected 1 customer after second check-in", 1, hotel.getCustomers().size());
        assertTrue("Room 1 should be occupied after second check-in", hotel.findRoom(1).isOccupied());

        Customer customer = hotel.getCustomers().get(0);
        assertEquals("Customer name should be 'Jane Smith'", "Jane Smith", customer.getName());
        assertEquals("Room number should be 1", 1, customer.getRoomNumber());
        assertEquals("Check-in date should match", checkInDate2, customer.getCheckInDate());
        assertEquals("Check-out date should match", checkOutDate2, customer.getCheckOutDate());
    }

    @Test
    public void testCheckInOverlappingDates() {
        LocalDate checkInDate1 = LocalDate.now();
        LocalDate checkOutDate1 = LocalDate.now().plusDays(2);
        LocalDate checkInDate2 = LocalDate.now().plusDays(1);
        LocalDate checkOutDate2 = LocalDate.now().plusDays(3);

        hotel.checkIn("John Doe", 1, checkInDate1, checkOutDate1);
        hotel.checkIn("Jane Smith", 2, checkInDate2, checkOutDate2);

        assertEquals("Expected 2 customers after overlapping check-ins", 2, hotel.getCustomers().size());
    }

    @Test
    public void testCheckOutNonExistingCustomer() {
        int initialCustomerCount = hotel.getCustomers().size();
        hotel.checkOut(101); // Assuming room number 101 doesn't exist
        assertEquals("Customer count should remain the same after trying to check out non-existing room", initialCustomerCount, hotel.getCustomers().size());
    }

    @Test
    public void testCheckOutUnoccupiedRoom() {
        // Ensure the room is unoccupied by explicitly checking out if needed
        hotel.checkOut(1);

        int initialCustomerCount = hotel.getCustomers().size();

        hotel.checkOut(1); // Assuming room number 1 is unoccupied
        assertEquals("Customer count should remain the same after trying to check out unoccupied room", initialCustomerCount, hotel.getCustomers().size());
    }

    @Test
    public void testDisplayRoomsOccupancy() {
        hotel.displayRooms();
        
    }

    @Test
    public void testCheckInWithPastDate() {
        LocalDate checkInDate = LocalDate.now().minusDays(1);
        LocalDate checkOutDate = LocalDate.now().plusDays(1);
        hotel.checkIn("John Doe", 1, checkInDate, checkOutDate);
        assertTrue("Customer list should be empty when checking in with a past date", hotel.getCustomers().isEmpty());
    }

    @Test
    public void testDisplayCustomersWithNames() {
        LocalDate checkInDate = LocalDate.now();
        LocalDate checkOutDate = LocalDate.now().plusDays(1);
        hotel.checkIn("John Doe", 1, checkInDate, checkOutDate);
        hotel.displayCustomers();
        // Check console output manually
    }
}
